import os
import sys
import requests

# Ensure local imports work
script_dir = os.path.dirname(os.path.abspath(__file__))
if script_dir not in sys.path:
    sys.path.insert(0, script_dir)

from LGBMfulldata import train_model_system
from Utils.mayor_utils import get_mayor_perks

# Top shards to train on initially
TOP_SHARDS = [
    "DIAMOND_SHARD",
    "GOLD_SHARD",
    "IRON_SHARD",
    "EMERALD_SHARD",
    "QUARTZ_SHARD"
]

def main():
    print("🚀 Starting initial model training for top items...")
    
    os.makedirs(os.path.join(script_dir, "Model_Files"), exist_ok=True)
    
    for item_id in TOP_SHARDS:
        print(f"\n--- Training {item_id} ---")
        try:
            train_model_system(item_id)
            print(f"✅ Finished {item_id}")
        except Exception as e:
            print(f"❌ Failed {item_id}: {e}")


    print("\n🎉 Initial training complete! You can now start the API.")

if __name__ == "__main__":
    main()

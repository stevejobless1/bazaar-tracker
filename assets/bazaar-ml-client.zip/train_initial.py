#!/usr/bin/env python3
"""
Bazaar ML Model Trainer
=======================
Trains LightGBM entry-prediction models for ALL items on the Hypixel Bazaar.
Fetches the full item list dynamically from the Coflnet API so nothing is hardcoded.

Usage:
    python train_initial.py                 # Train all bazaar items
    python train_initial.py --workers 4     # Train with 4 parallel workers
    python train_initial.py --items 50      # Train on first 50 items only (for testing)
"""
import os
import sys
import time
import requests
import argparse
import traceback
from concurrent.futures import ThreadPoolExecutor, as_completed

script_dir = os.path.dirname(os.path.abspath(__file__))
if script_dir not in sys.path:
    sys.path.insert(0, script_dir)

from LGBMfulldata import train_model_system


def fetch_all_bazaar_items():
    """Fetch every bazaar item ID from the Coflnet API."""
    url = "https://sky.coflnet.com/api/items/bazaar/tags"
    print(f"📡 Fetching full bazaar item list from {url}...")
    try:
        resp = requests.get(url, timeout=15)
        resp.raise_for_status()
        items = resp.json()
        if not isinstance(items, list):
            raise ValueError("API did not return a list")
        print(f"✅ Found {len(items)} bazaar items\n")
        return items
    except Exception as e:
        print(f"❌ Failed to fetch item list: {e}")
        sys.exit(1)


def train_single_item(item_id):
    """Train a model for a single item. Returns (item_id, success, error_msg)."""
    try:
        train_model_system(item_id)
        return (item_id, True, None)
    except Exception as e:
        return (item_id, False, str(e))


def main():
    parser = argparse.ArgumentParser(description="Train bazaar ML models")
    parser.add_argument("--workers", type=int, default=1,
                        help="Number of parallel training workers (default: 1, sequential)")
    parser.add_argument("--items", type=int, default=0,
                        help="Limit to first N items (0 = all, useful for testing)")
    args = parser.parse_args()

    print("=" * 60)
    print("  🚀 Bazaar ML Model Trainer")
    print("=" * 60)

    all_items = fetch_all_bazaar_items()

    if args.items > 0:
        all_items = all_items[:args.items]
        print(f"⚠️  Limited to first {args.items} items for this run\n")

    os.makedirs(os.path.join(script_dir, "Model_Files"), exist_ok=True)

    total = len(all_items)
    succeeded = 0
    failed = 0
    failed_items = []
    start_time = time.time()

    if args.workers > 1:
        print(f"🔧 Training {total} items with {args.workers} parallel workers...\n")
        with ThreadPoolExecutor(max_workers=args.workers) as pool:
            futures = {pool.submit(train_single_item, item): item for item in all_items}
            for i, future in enumerate(as_completed(futures), 1):
                item_id, success, err = future.result()
                if success:
                    succeeded += 1
                    print(f"  [{i}/{total}] ✅ {item_id}")
                else:
                    failed += 1
                    failed_items.append(item_id)
                    print(f"  [{i}/{total}] ❌ {item_id}: {err}")
    else:
        print(f"🔧 Training {total} items sequentially...\n")
        for i, item_id in enumerate(all_items, 1):
            print(f"  [{i}/{total}] Training {item_id}...", end=" ", flush=True)
            item_id, success, err = train_single_item(item_id)
            if success:
                succeeded += 1
                print("✅")
            else:
                failed += 1
                failed_items.append(item_id)
                print(f"❌ {err}")

    elapsed = time.time() - start_time
    minutes = int(elapsed // 60)
    seconds = int(elapsed % 60)

    print("\n" + "=" * 60)
    print("  📊 Training Summary")
    print("=" * 60)
    print(f"  Total items:    {total}")
    print(f"  Succeeded:      {succeeded}")
    print(f"  Failed:         {failed}")
    print(f"  Time elapsed:   {minutes}m {seconds}s")

    if failed_items:
        print(f"\n  Failed items:")
        for item in failed_items:
            print(f"    - {item}")

    print(f"\n🎉 Training complete! Models saved to {os.path.join(script_dir, 'Model_Files')}")
    print("   You can now run: python predict_client.py")


if __name__ == "__main__":
    main()

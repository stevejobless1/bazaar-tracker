#!/usr/bin/env python3
"""
Bazaar ML Model Trainer
=======================
Trains LightGBM entry-prediction models for ALL items on the Hypixel Bazaar.

Performance:
  - Async batch fetching: Downloads data for all items concurrently (~10-20x faster)
  - GPU acceleration: Uses OpenCL (works with AMD, NVIDIA, Intel GPUs)
  - Parallel training: Multiple items train simultaneously via thread pool

Usage:
    python train_initial.py                 # Train all bazaar items
    python train_initial.py --workers 4     # Train with 4 parallel workers
    python train_initial.py --items 50      # Train first 50 items only (testing)
    python train_initial.py --concurrent 30 # Increase async fetch concurrency
"""
import os
import sys
import time
import argparse
import traceback
from concurrent.futures import ThreadPoolExecutor, as_completed

script_dir = os.path.dirname(os.path.abspath(__file__))
if script_dir not in sys.path:
    sys.path.insert(0, script_dir)

from LGBMfulldata import train_model_system, detect_gpu
from Utils.data_utils import fetch_all_product_ids, fetch_all_items_async
from Utils.mayor_utils import get_mayor_perks


def train_single_item(item_id, prefetched_data, mayor_data):
    """Train a model for a single item. Returns (item_id, success, error_msg)."""
    try:
        data = prefetched_data.get(item_id, [])
        if not data:
            return (item_id, False, "no data available")
        train_model_system(item_id, prefetched_data=data, mayor_data=mayor_data)
        return (item_id, True, None)
    except Exception as e:
        return (item_id, False, str(e))


def main():
    parser = argparse.ArgumentParser(description="Train bazaar ML models")
    parser.add_argument("--workers", type=int, default=1,
                        help="Number of parallel training workers (default: 1)")
    parser.add_argument("--items", type=int, default=0,
                        help="Limit to first N items (0 = all)")
    parser.add_argument("--concurrent", type=int, default=20,
                        help="Max concurrent async data fetches (default: 20)")
    args = parser.parse_args()

    print("=" * 60)
    print("  🚀 Bazaar ML Model Trainer")
    print("=" * 60)

    # ── GPU Detection ────────────────────────────────────────────
    gpu = detect_gpu()
    print(f"  GPU:    {'✅ Enabled (OpenCL)' if gpu else '❌ Not available (using CPU)'}")
    if not gpu:
        print("         To enable GPU: install OpenCL drivers for your GPU")
        print("         AMD: Install AMD Adrenalin drivers")
        print("         NVIDIA: Install CUDA toolkit")
    print()

    # ── Fetch Item List ──────────────────────────────────────────
    all_items = fetch_all_product_ids()
    if not all_items:
        print("❌ Could not fetch any item IDs")
        sys.exit(1)
    print(f"📦 Found {len(all_items)} bazaar items")

    if args.items > 0:
        all_items = all_items[:args.items]
        print(f"⚠️  Limited to first {args.items} items for this run")

    # ── Pre-fetch Mayor Data ─────────────────────────────────────
    print("📡 Fetching mayor perk data...")
    try:
        mayor_data = get_mayor_perks()
        print(f"   ✅ Got {len(mayor_data)} mayor entries")
    except Exception as e:
        print(f"   ⚠️  Mayor data unavailable ({e}), continuing without")
        mayor_data = None

    # ── Async Batch Fetch All Item Data ──────────────────────────
    print(f"\n⚡ Fetching data for {len(all_items)} items asynchronously "
          f"(max {args.concurrent} concurrent)...")
    fetch_start = time.time()
    prefetched = fetch_all_items_async(all_items, max_concurrent=args.concurrent)
    fetch_elapsed = time.time() - fetch_start

    items_with_data = sum(1 for v in prefetched.values() if v)
    items_no_data = len(all_items) - items_with_data
    print(f"   ✅ Fetched in {fetch_elapsed:.1f}s — "
          f"{items_with_data} with data, {items_no_data} empty")

    # Filter to only items that have data
    trainable_items = [item for item in all_items if prefetched.get(item)]
    if not trainable_items:
        print("❌ No items have data to train on")
        sys.exit(1)

    # ── Training ─────────────────────────────────────────────────
    os.makedirs(os.path.join(script_dir, "Model_Files"), exist_ok=True)

    total = len(trainable_items)
    succeeded = 0
    failed = 0
    failed_items = []
    train_start = time.time()

    if args.workers > 1:
        print(f"\n🔧 Training {total} items with {args.workers} parallel workers...\n")
        with ThreadPoolExecutor(max_workers=args.workers) as pool:
            futures = {
                pool.submit(train_single_item, item, prefetched, mayor_data): item
                for item in trainable_items
            }
            for i, future in enumerate(as_completed(futures), 1):
                item_id, success, err = future.result()
                if success:
                    succeeded += 1
                    print(f"  [{i}/{total}] ✅ {item_id}")
                else:
                    failed += 1
                    failed_items.append((item_id, err))
                    print(f"  [{i}/{total}] ❌ {item_id}: {err}")
    else:
        print(f"\n🔧 Training {total} items sequentially...\n")
        for i, item_id in enumerate(trainable_items, 1):
            print(f"  [{i}/{total}] Training {item_id}...", end=" ", flush=True)
            _, success, err = train_single_item(item_id, prefetched, mayor_data)
            if success:
                succeeded += 1
                print("✅")
            else:
                failed += 1
                failed_items.append((item_id, err))
                print(f"❌ {err}")

    train_elapsed = time.time() - train_start
    total_elapsed = time.time() - fetch_start

    print("\n" + "=" * 60)
    print("  📊 Training Summary")
    print("=" * 60)
    print(f"  Total items:       {len(all_items)}")
    print(f"  Had data:          {items_with_data}")
    print(f"  Trained OK:        {succeeded}")
    print(f"  Failed:            {failed}")
    print(f"  Fetch time:        {fetch_elapsed:.1f}s")
    print(f"  Training time:     {train_elapsed:.1f}s")
    print(f"  Total time:        {total_elapsed:.1f}s")
    print(f"  Device:            {'GPU (OpenCL)' if gpu else 'CPU'}")

    if failed_items:
        print(f"\n  Failed items ({len(failed_items)}):")
        for item, err in failed_items[:20]:
            print(f"    - {item}: {err}")
        if len(failed_items) > 20:
            print(f"    ... and {len(failed_items) - 20} more")

    print(f"\n🎉 Done! {succeeded} models saved to {os.path.join(script_dir, 'Model_Files')}")
    print("   Run: python predict_client.py")


if __name__ == "__main__":
    main()

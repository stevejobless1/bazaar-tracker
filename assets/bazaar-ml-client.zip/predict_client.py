#!/usr/bin/env python3
"""
Bazaar ML Prediction Client
============================
Runs locally on your PC, loads trained models, makes predictions for every
item that has a trained model, and uploads results to the live dashboard.

Usage:
    python predict_client.py                                          # defaults
    python predict_client.py --url https://bazaar.cows.boats/api/ml/upload
    python predict_client.py --interval 120                           # every 2 min
    python predict_client.py --once                                   # single run
"""
import joblib
import os
import requests
import json
import time
from datetime import datetime, timezone
import sys
import argparse
import traceback

script_dir = os.path.dirname(os.path.abspath(__file__))
if script_dir not in sys.path:
    sys.path.insert(0, script_dir)

from LGBMfulldata import predict_entries, analyze_entries
from Utils.mayor_utils import get_mayor_perks

MODEL_DIR = os.path.join(script_dir, "Model_Files")


def discover_trained_items():
    """Scan Model_Files to find every item that has a complete set of model artifacts."""
    items = []
    if not os.path.exists(MODEL_DIR):
        return items
    for fname in os.listdir(MODEL_DIR):
        if fname.endswith("_entry_model.pkl"):
            item_id = fname.replace("_entry_model.pkl", "")
            scaler = os.path.join(MODEL_DIR, f"{item_id}_entry_scaler.pkl")
            features = os.path.join(MODEL_DIR, f"{item_id}_entry_features.pkl")
            if os.path.exists(scaler) and os.path.exists(features):
                items.append(item_id)
    return sorted(items)


def run_predictions(api_url, password):
    """Load every trained model, predict, and upload to the dashboard."""
    items = discover_trained_items()
    if not items:
        print("⚠️  No trained models found in Model_Files/")
        print("   Run 'python train_initial.py' first to train models.")
        return

    print(f"\n📦 Found {len(items)} trained models")
    print("📡 Fetching mayor data...")

    try:
        mayor_data_cache = get_mayor_perks()
    except Exception as e:
        print(f"⚠️  Mayor data unavailable ({e}), continuing without it")
        mayor_data_cache = None

    results = []
    errors = 0

    for i, item_id in enumerate(items, 1):
        try:
            model = joblib.load(os.path.join(MODEL_DIR, f"{item_id}_entry_model.pkl"))
            scaler = joblib.load(os.path.join(MODEL_DIR, f"{item_id}_entry_scaler.pkl"))
            features = joblib.load(os.path.join(MODEL_DIR, f"{item_id}_entry_features.pkl"))

            preds = predict_entries(model, scaler, features, item_id, mayor_data_cache)
            ranked = analyze_entries(preds)

            if ranked:
                best = ranked[0]
                results.append({
                    'item_id': item_id,
                    'timestamp': best['timestamp'],
                    'buy_price': best['buy_price'],
                    'sell_price': best['sell_price'],
                    'entry_score': best['entry_score'],
                    'delta_minutes': best['delta_minutes'],
                    'entries': ranked
                })
                print(f"  [{i}/{len(items)}] ✅ {item_id}: score={best['entry_score']:.4f}")
            else:
                print(f"  [{i}/{len(items)}] ⏭️  {item_id}: no positive signals")
        except Exception as e:
            errors += 1
            print(f"  [{i}/{len(items)}] ❌ {item_id}: {e}")

    results.sort(key=lambda x: (x['delta_minutes'], -x['entry_score']))

    payload = {
        'items': results,
        'total': len(results),
        'generated_at': datetime.now(timezone.utc).isoformat()
    }

    print(f"\n📤 Uploading {len(results)} predictions to {api_url}...")
    if errors:
        print(f"   ({errors} items had errors and were skipped)")

    try:
        headers = {'Content-Type': 'application/json'}
        if password:
            headers['Authorization'] = f'Bearer {password}'
        res = requests.post(api_url, json=payload, headers=headers, timeout=15)
        if res.status_code == 200:
            print("✅ Successfully uploaded predictions!")
        else:
            print(f"❌ Upload failed: {res.status_code} - {res.text}")
    except Exception as e:
        print(f"❌ Connection error: {e}")


if __name__ == '__main__':
    parser = argparse.ArgumentParser(description='Bazaar ML Prediction Client')
    parser.add_argument('--url', type=str,
                        default='https://bazaar.cows.boats/api/ml/upload',
                        help='API endpoint to upload predictions to')
    parser.add_argument('--password', type=str, default='fusion',
                        help='Dashboard password for authorization')
    parser.add_argument('--interval', type=int, default=60,
                        help='Seconds between prediction cycles (default: 60)')
    parser.add_argument('--once', action='store_true',
                        help='Run once and exit instead of looping')

    args = parser.parse_args()

    print("=" * 60)
    print("  🧠 Bazaar ML Prediction Client")
    print("=" * 60)
    print(f"  Target: {args.url}")
    print(f"  Mode:   {'single run' if args.once else f'loop every {args.interval}s'}")
    print()

    if args.once:
        run_predictions(args.url, args.password)
    else:
        while True:
            run_predictions(args.url, args.password)
            print(f"\n⏳ Waiting {args.interval}s before next cycle...\n")
            time.sleep(args.interval)

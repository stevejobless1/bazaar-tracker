import joblib
import os
import requests
import json
import time
from datetime import datetime, timezone
import sys
import argparse

script_dir = os.path.dirname(os.path.abspath(__file__))
if script_dir not in sys.path:
    sys.path.insert(0, script_dir)

from LGBMfulldata import predict_entries, analyze_entries
from Utils.mayor_utils import get_mayor_perks

MODEL_DIR = os.path.join(script_dir, "Model_Files")

def run_predictions(api_url, password):
    print("\nLoading models and making predictions...")
    url = "https://sky.coflnet.com/api/items/bazaar/tags"
    try:
        item_ids = requests.get(url).json()
    except Exception as e:
        print(f"Failed to fetch item IDs: {e}")
        return

    try:
        mayor_data_cache = get_mayor_perks()
    except Exception as e:
        print(f"Failed to fetch mayor perks: {e}")
        mayor_data_cache = None

    results = []
    
    for item_id in item_ids:
        model_path = os.path.join(MODEL_DIR, f'{item_id}_entry_model.pkl')
        scaler_path = os.path.join(MODEL_DIR, f'{item_id}_entry_scaler.pkl')
        features_path = os.path.join(MODEL_DIR, f'{item_id}_entry_features.pkl')

        if not os.path.exists(model_path):
            continue

        try:
            model = joblib.load(model_path)
            scaler = joblib.load(scaler_path)
            features = joblib.load(features_path)
            
            preds = predict_entries(model, scaler, features, item_id, mayor_data_cache)
            ranked = analyze_entries(preds)
            
            if ranked:
                best = ranked[0]
                results.append({
                    'item_id': item_id,
                    'timestamp': best['timestamp'],
                    'buy_price': best['buy_price'],
                    'sell_price': best['sell_price'],
                    'entry_score': best['entry_score'],
                    'delta_minutes': best['delta_minutes'],
                    'entries': ranked
                })
                print(f"✅ Predicted {item_id}: Score {best['entry_score']:.2f}")
        except Exception as e:
            print(f"❌ Error predicting {item_id}: {e}")

    results.sort(key=lambda x: (x['delta_minutes'], -x['entry_score']))
    
    payload = {
        'items': results,
        'total': len(results)
    }
    
    print(f"\nUploading {len(results)} predictions to {api_url}...")
    try:
        headers = {'Authorization': f'Bearer {password}'} if password else {}
        res = requests.post(api_url, json=payload, headers=headers)
        if res.status_code == 200:
            print("Successfully uploaded predictions!")
        else:
            print(f"Failed to upload predictions: {res.status_code} - {res.text}")
    except Exception as e:
        print(f"Failed to connect to API: {e}")

if __name__ == '__main__':
    parser = argparse.ArgumentParser(description='Bazaar ML Prediction Client')
    parser.add_argument('--url', type=str, default='https://tracker.yourdomain.com/api/ml/upload', help='The Bazaar Tracker API URL to upload predictions to')
    parser.add_argument('--password', type=str, default='fusion', help='Dashboard password for authorization')
    parser.add_argument('--interval', type=int, default=60, help='Interval between prediction runs in seconds')
    
    args = parser.parse_args()
    
    print(f"Starting ML Client targeting {args.url}")
    while True:
        run_predictions(args.url, args.password)
        print(f"\nWaiting {args.interval} seconds before next prediction cycle...")
        time.sleep(args.interval)

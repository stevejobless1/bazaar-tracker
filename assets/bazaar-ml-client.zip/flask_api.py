from flask import Flask, jsonify, request
from flask_cors import CORS
import joblib
import os
import requests
import json
import threading
import time
from datetime import datetime, timezone
import traceback
import sys

# Ensure local imports work
script_dir = os.path.dirname(os.path.abspath(__file__))
if script_dir not in sys.path:
    sys.path.insert(0, script_dir)

from LGBMfulldata import predict_entries, analyze_entries
from Utils.mayor_utils import get_mayor_perks

app = Flask(__name__)
CORS(app)

MODEL_DIR = os.path.join(script_dir, "Model_Files")

# Global artifacts
models_dict = {}
scalers_dict = {}
feature_columns_dict = {}
mayor_data_cache = None
model_trained = False

# Cached predictions
cached_predictions = {}
predictions_file = os.path.join(MODEL_DIR, 'predictions_cache.json')
prediction_lock = threading.Lock()

def load_model_artifacts():
    global models_dict, scalers_dict, feature_columns_dict, mayor_data_cache, model_trained
    try:
        url = "https://sky.coflnet.com/api/items/bazaar/tags"
        item_ids = requests.get(url).json()
        mayor_data_cache = get_mayor_perks()
        
        models_dict.clear()
        scalers_dict.clear()
        feature_columns_dict.clear()

        for item_id in item_ids:
            model_path = os.path.join(MODEL_DIR, f'{item_id}_entry_model.pkl')
            scaler_path = os.path.join(MODEL_DIR, f'{item_id}_entry_scaler.pkl')
            features_path = os.path.join(MODEL_DIR, f'{item_id}_entry_features.pkl')

            if os.path.exists(model_path):
                models_dict[item_id] = {"model_path": model_path}
                scalers_dict[item_id] = {"scaler_path": scaler_path}
                feature_columns_dict[item_id] = {"features_path": features_path}

        model_trained = len(models_dict) > 0
        print(f"✅ Loaded models for {len(models_dict)} items")
        return model_trained
    except Exception as e:
        print(f"❌ Error loading models: {e}")
        return False

def get_available_items():
    items = []
    if os.path.exists(MODEL_DIR):
        for fname in os.listdir(MODEL_DIR):
            if fname.endswith("_entry_model.pkl"):
                items.append(fname.replace("_entry_model.pkl", ""))
    return items

def background_prediction_loop():
    global cached_predictions
    while True:
        try:
            if not model_trained:
                time.sleep(10)
                continue
            items = get_available_items()
            for item_id in items:
                try:
                    model = joblib.load(models_dict[item_id]["model_path"])
                    scaler = joblib.load(scalers_dict[item_id]["scaler_path"])
                    features = joblib.load(feature_columns_dict[item_id]["features_path"])
                    
                    preds = predict_entries(model, scaler, features, item_id, mayor_data_cache)
                    ranked = analyze_entries(preds)
                    
                    with prediction_lock:
                        cached_predictions[item_id] = {
                            'item_id': item_id,
                            'timestamp': datetime.now(timezone.utc).isoformat(),
                            'entries': ranked
                        }
                except: continue
            time.sleep(60)
        except Exception as e:
            print(f"❌ Prediction loop error: {e}")
            time.sleep(30)

@app.route('/health')
def health():
    return jsonify({'status': 'healthy', 'model_trained': model_trained})

@app.route('/predictions')
def get_predictions():
    limit = int(request.args.get('limit', 100))
    min_score = float(request.args.get('min_score', 0.0))
    
    with prediction_lock:
        preds = list(cached_predictions.values())
    
    results = []
    for p in preds:
        entries = p.get('entries') or []
        if not entries: continue
        best = entries[0]
        if best.get('entry_score', 0) > min_score:
            results.append({
                'item_id': p['item_id'],
                'timestamp': best['timestamp'],
                'buy_price': best['buy_price'],
                'sell_price': best['sell_price'],
                'entry_score': best['entry_score'],
                'delta_minutes': best['delta_minutes']
            })
    
    results.sort(key=lambda x: (x['delta_minutes'], -x['entry_score']))
    return jsonify({'items': results[:limit], 'total': len(results)})

@app.route('/predict/<item_id>')
def predict_single(item_id):
    if item_id not in models_dict:
        return jsonify({'error': 'No model for this item'}), 404
    try:
        model = joblib.load(models_dict[item_id]["model_path"])
        scaler = joblib.load(scalers_dict[item_id]["scaler_path"])
        features = joblib.load(feature_columns_dict[item_id]["features_path"])
        preds = predict_entries(model, scaler, features, item_id, mayor_data_cache)
        return jsonify({'item_id': item_id, 'entries': analyze_entries(preds)})
    except Exception as e:
        return jsonify({'error': str(e)}), 500

if __name__ == '__main__':
    load_model_artifacts()
    threading.Thread(target=background_prediction_loop, daemon=True).start()
    app.run(host='0.0.0.0', port=5001)

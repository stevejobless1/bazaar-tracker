import requests
import json
import os
from datetime import datetime, timezone, timedelta
from dateutil import parser


# ── Configuration ────────────────────────────────────────────────────────────
# Your own tracker has weeks of high-resolution data; Coflnet only gives ~72h.
# We try your tracker first, fall back to Coflnet if it's unavailable.
TRACKER_BASE = os.environ.get("TRACKER_URL", "https://bazaar.cows.boats")
TRACKER_PASSWORD = os.environ.get("TRACKER_PASSWORD", "fusion")


def parse_timestamp(ts_str):
    """Parse any timestamp format into a timezone-aware UTC datetime."""
    if isinstance(ts_str, (int, float)):
        # Epoch milliseconds from the tracker DB
        return datetime.fromtimestamp(ts_str / 1000, tz=timezone.utc)
    try:
        dt = parser.parse(str(ts_str))
        if dt.tzinfo is None:
            dt = dt.replace(tzinfo=timezone.utc)
        return dt.astimezone(timezone.utc)
    except:
        raise ValueError(f"Unrecognized timestamp format: {ts_str}")


def fetch_from_tracker(item_id, resolution="5m", limit=5000):
    """
    Fetch historical data from the bazaar.cows.boats tracker API.
    Returns a list of dicts with keys: timestamp, buy, sell, buyVolume, sellVolume
    (normalized to match the format LGBMfulldata expects).
    """
    url = f"{TRACKER_BASE}/api/bazaar/history/{item_id}?resolution={resolution}&limit={limit}"
    headers = {"Authorization": f"Bearer {TRACKER_PASSWORD}"} if TRACKER_PASSWORD else {}
    try:
        resp = requests.get(url, headers=headers, timeout=20)
        resp.raise_for_status()
        body = resp.json()
        if not body.get("success"):
            return []

        raw_data = body.get("data", [])
        if not raw_data:
            return []

        # Normalize field names to what LGBMfulldata.prepare_dataframe_from_raw expects
        normalized = []
        for row in raw_data:
            normalized.append({
                "timestamp": row.get("timestamp"),  # epoch ms
                "buy": row.get("buy_price") or row.get("buyPrice") or row.get("buy_close", 0),
                "sell": row.get("sell_price") or row.get("sellPrice") or row.get("sell_close", 0),
                "buyVolume": row.get("buy_volume") or row.get("buyVolume") or row.get("avg_buy_volume", 0),
                "sellVolume": row.get("sell_volume") or row.get("sellVolume") or row.get("avg_sell_volume", 0),
                "maxBuy": row.get("buy_price") or row.get("buyPrice") or 0,
                "minBuy": row.get("sell_price") or row.get("sellPrice") or 0,
            })
        return normalized
    except Exception as e:
        return []


def fetch_from_coflnet(item_id, start=None, end=None):
    """Fetch from Coflnet public API (fallback, ~72h of data)."""
    if end is None:
        end = datetime.now(timezone.utc)
    if start is None:
        start = end - timedelta(hours=72)

    if isinstance(start, str):
        start = parse_timestamp(start)
    if isinstance(end, str):
        end = parse_timestamp(end)

    start_str = start.strftime("%Y-%m-%dT%H:%M:%S.000").replace(":", "%3A")
    end_str = end.strftime("%Y-%m-%dT%H:%M:%S.000").replace(":", "%3A")

    url = f"https://sky.coflnet.com/api/bazaar/{item_id}/history?start={start_str}&end={end_str}"
    try:
        resp = requests.get(url, timeout=15)
        data = resp.json()
        return data if isinstance(data, list) else ([data] if isinstance(data, dict) else [])
    except Exception as e:
        print(f"    ⚠️  Coflnet fetch error for {item_id}: {e}")
        return []


def load_or_fetch_item_data(item_id, start=None, end=None):
    """
    Primary data loader. Tries the user's own tracker first (more data),
    falls back to Coflnet if the tracker is unavailable.
    """
    # For training (no start/end) → use tracker's deep history
    if start is None and end is None:
        data = fetch_from_tracker(item_id, resolution="5m", limit=5000)
        if data:
            return data

    # For live prediction (specific time range) or if tracker failed → Coflnet
    return fetch_from_coflnet(item_id, start, end)


def fetch_all_product_ids():
    """
    Get the list of every bazaar product ID.
    Tries the user's tracker first, falls back to Coflnet.
    """
    # Try tracker: /api/bazaar returns { products: { ITEM_ID: {...}, ... } }
    try:
        headers = {"Authorization": f"Bearer {TRACKER_PASSWORD}"} if TRACKER_PASSWORD else {}
        resp = requests.get(f"{TRACKER_BASE}/api/bazaar", headers=headers, timeout=15)
        resp.raise_for_status()
        body = resp.json()
        if body.get("success") and body.get("products"):
            items = list(body["products"].keys())
            if items:
                return items
    except:
        pass

    # Fallback: Coflnet tag list
    try:
        resp = requests.get("https://sky.coflnet.com/api/items/bazaar/tags", timeout=15)
        resp.raise_for_status()
        return resp.json()
    except Exception as e:
        print(f"❌ Could not fetch item list: {e}")
        return []

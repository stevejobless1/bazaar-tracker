import requests
import json
import os
import asyncio
import aiohttp
from datetime import datetime, timezone, timedelta
from dateutil import parser


# ── Configuration ────────────────────────────────────────────────────────────
TRACKER_BASE = os.environ.get("TRACKER_URL", "https://bazaar.cows.boats")
TRACKER_PASSWORD = os.environ.get("TRACKER_PASSWORD", "fusion")


def parse_timestamp(ts_str):
    """Parse any timestamp format into a timezone-aware UTC datetime."""
    if isinstance(ts_str, (int, float)):
        return datetime.fromtimestamp(ts_str / 1000, tz=timezone.utc)
    try:
        dt = parser.parse(str(ts_str))
        if dt.tzinfo is None:
            dt = dt.replace(tzinfo=timezone.utc)
        return dt.astimezone(timezone.utc)
    except:
        raise ValueError(f"Unrecognized timestamp format: {ts_str}")


# ── Synchronous Fetchers (for single-item use) ──────────────────────────────

def _normalize_tracker_row(row):
    """Normalize a tracker API row to the format LGBMfulldata expects."""
    return {
        "timestamp": row.get("timestamp"),
        "buy": row.get("buy_price") or row.get("buyPrice") or row.get("buy_close", 0),
        "sell": row.get("sell_price") or row.get("sellPrice") or row.get("sell_close", 0),
        "buyVolume": row.get("buy_volume") or row.get("buyVolume") or row.get("avg_buy_volume", 0),
        "sellVolume": row.get("sell_volume") or row.get("sellVolume") or row.get("avg_sell_volume", 0),
        "maxBuy": row.get("buy_price") or row.get("buyPrice") or 0,
        "minBuy": row.get("sell_price") or row.get("sellPrice") or 0,
    }


def fetch_from_tracker(item_id, resolution="5m", limit=5000):
    """Fetch historical data from bazaar.cows.boats (sync)."""
    url = f"{TRACKER_BASE}/api/bazaar/history/{item_id}?resolution={resolution}&limit={limit}"
    headers = {"Authorization": f"Bearer {TRACKER_PASSWORD}"} if TRACKER_PASSWORD else {}
    try:
        resp = requests.get(url, headers=headers, timeout=20)
        resp.raise_for_status()
        body = resp.json()
        if not body.get("success"):
            return []
        return [_normalize_tracker_row(r) for r in body.get("data", [])]
    except:
        return []


def fetch_from_coflnet(item_id, start=None, end=None):
    """Fetch from Coflnet public API (fallback, ~72h of data)."""
    if end is None:
        end = datetime.now(timezone.utc)
    if start is None:
        start = end - timedelta(hours=72)
    if isinstance(start, str):
        start = parse_timestamp(start)
    if isinstance(end, str):
        end = parse_timestamp(end)

    start_str = start.strftime("%Y-%m-%dT%H:%M:%S.000").replace(":", "%3A")
    end_str = end.strftime("%Y-%m-%dT%H:%M:%S.000").replace(":", "%3A")

    url = f"https://sky.coflnet.com/api/bazaar/{item_id}/history?start={start_str}&end={end_str}"
    try:
        resp = requests.get(url, timeout=15)
        data = resp.json()
        return data if isinstance(data, list) else ([data] if isinstance(data, dict) else [])
    except:
        return []


def load_or_fetch_item_data(item_id, start=None, end=None):
    """Primary sync loader. Tries tracker first, falls back to Coflnet."""
    if start is None and end is None:
        data = fetch_from_tracker(item_id, resolution="5m", limit=5000)
        if data:
            return data
    return fetch_from_coflnet(item_id, start, end)


def fetch_all_product_ids():
    """Get every bazaar product ID. Tries tracker first, falls back to Coflnet."""
    try:
        headers = {"Authorization": f"Bearer {TRACKER_PASSWORD}"} if TRACKER_PASSWORD else {}
        resp = requests.get(f"{TRACKER_BASE}/api/bazaar", headers=headers, timeout=15)
        resp.raise_for_status()
        body = resp.json()
        if body.get("success") and body.get("products"):
            items = list(body["products"].keys())
            if items:
                return items
    except:
        pass
    try:
        resp = requests.get("https://sky.coflnet.com/api/items/bazaar/tags", timeout=15)
        resp.raise_for_status()
        return resp.json()
    except Exception as e:
        print(f"❌ Could not fetch item list: {e}")
        return []


# ── Async Batch Fetching ─────────────────────────────────────────────────────
# Fetches data for ALL items concurrently instead of one-by-one.

async def _async_fetch_single(session, item_id, semaphore, resolution="5m", limit=5000):
    """Fetch data for a single item using aiohttp (async)."""
    url = f"{TRACKER_BASE}/api/bazaar/history/{item_id}?resolution={resolution}&limit={limit}"
    headers = {"Authorization": f"Bearer {TRACKER_PASSWORD}"} if TRACKER_PASSWORD else {}

    async with semaphore:
        try:
            async with session.get(url, headers=headers, timeout=aiohttp.ClientTimeout(total=30)) as resp:
                if resp.status == 200:
                    body = await resp.json()
                    if body.get("success") and body.get("data"):
                        return (item_id, [_normalize_tracker_row(r) for r in body["data"]])
        except:
            pass

        # Fallback to Coflnet
        now = datetime.now(timezone.utc)
        start = now - timedelta(hours=72)
        start_str = start.strftime("%Y-%m-%dT%H:%M:%S.000").replace(":", "%3A")
        end_str = now.strftime("%Y-%m-%dT%H:%M:%S.000").replace(":", "%3A")
        coflnet_url = f"https://sky.coflnet.com/api/bazaar/{item_id}/history?start={start_str}&end={end_str}"

        try:
            async with session.get(coflnet_url, timeout=aiohttp.ClientTimeout(total=15)) as resp:
                if resp.status == 200:
                    data = await resp.json()
                    if isinstance(data, list) and data:
                        return (item_id, data)
        except:
            pass

    return (item_id, [])


async def _async_fetch_all(item_ids, max_concurrent=20):
    """Fetch data for all items concurrently with a concurrency limiter."""
    semaphore = asyncio.Semaphore(max_concurrent)
    connector = aiohttp.TCPConnector(limit=max_concurrent, ssl=False)
    results = {}

    async with aiohttp.ClientSession(connector=connector) as session:
        tasks = [_async_fetch_single(session, item_id, semaphore) for item_id in item_ids]
        for coro in asyncio.as_completed(tasks):
            item_id, data = await coro
            results[item_id] = data

    return results


def fetch_all_items_async(item_ids, max_concurrent=20):
    """
    Fetch historical data for ALL items concurrently.
    Returns dict: { item_id: [data_rows, ...] }
    
    This is 10-20x faster than fetching sequentially.
    """
    try:
        loop = asyncio.get_running_loop()
    except RuntimeError:
        loop = None

    if loop and loop.is_running():
        # If we're already in an async context, use nest_asyncio or thread
        import concurrent.futures
        with concurrent.futures.ThreadPoolExecutor(max_workers=1) as pool:
            future = pool.submit(asyncio.run, _async_fetch_all(item_ids, max_concurrent))
            return future.result()
    else:
        return asyncio.run(_async_fetch_all(item_ids, max_concurrent))

import requests
import json
import os
from datetime import datetime, timezone, timedelta
from dateutil import parser

def parse_timestamp(ts_str):
    if isinstance(ts_str, (int, float)):
        return datetime.fromtimestamp(ts_str / 1000, tz=timezone.utc)
    try:
        dt = parser.parse(str(ts_str))
        if dt.tzinfo is None:
            dt = dt.replace(tzinfo=timezone.utc)
        return dt.astimezone(timezone.utc)
    except:
        raise ValueError(f"Unrecognized timestamp format: {ts_str}")

def fetch_range_data(item_id, start=None, end=None):
    if end is None:
        end = datetime.now(timezone.utc)
    if start is None:
        start = end - timedelta(hours=72)
    
    # Ensure datetimes
    if isinstance(start, str): start = parse_timestamp(start)
    if isinstance(end, str): end = parse_timestamp(end)
    
    start_str = start.strftime("%Y-%m-%dT%H:%M:%S.000").replace(":", "%3A")
    end_str = end.strftime("%Y-%m-%dT%H:%M:%S.000").replace(":", "%3A")
    
    url = f"https://sky.coflnet.com/api/bazaar/{item_id}/history?start={start_str}&end={end_str}"
    try:
        resp = requests.get(url, timeout=15)
        data = resp.json()
        return data if isinstance(data, list) else ([data] if isinstance(data, dict) else [])
    except Exception as e:
        print(f"Error fetching data for {item_id}: {e}")
        return []

def load_or_fetch_item_data(item_id, start=None, end=None):
    # This is used for both training and inference
    return fetch_range_data(item_id, start, end)

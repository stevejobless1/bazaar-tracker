import requests
import re
import os
from datetime import datetime, timezone
import json

def get_mayor_perks():
    """Fetch mayor perks data and return as binary vectors with timestamps."""
    current_datetime = datetime.now(timezone.utc)
    # Fetch from Coflnet for historical data
    url = f"https://sky.coflnet.com/api/mayor?from=2022-05-17T20%3A03%3A10.937Z&to={current_datetime.strftime('%Y-%m-%dT%H%%3A%M%%3A%S.%fZ')}"
    
    try:
        response = requests.get(url)
        html_content = response.text
        mayors = html_content.split('"start"')
        mayors.pop(0)
    except:
        mayors = []
    
    mayor_data = []
    perk_file = os.path.join(os.path.dirname(__file__), "perk_names.txt")
    if os.path.exists(perk_file):
        with open(perk_file, 'r') as file:
            perk_names = file.read().splitlines()
    else:
        perk_names = []

    for mayor in mayors:
        # Date format is MM/DD/YYYY in the API response
        start_match = re.search(r'(\d{2}/\d{2}/\d{4})', mayor)
        if not start_match:
            continue
        start_date = datetime.strptime(start_match.group(1), '%m/%d/%Y').replace(tzinfo=timezone.utc)
        
        binary_perks = [0 for _ in range(40)]
        matches = re.findall(r'"name":"([^"]*)"', mayor)
        
        for perk_name in matches:
            if perk_name in perk_names:
                perk_index = perk_names.index(perk_name)
                if perk_index < 40:
                    binary_perks[perk_index] = 1
        
        mayor_data.append({
            'start_date': start_date,
            'perks': binary_perks
        })
    
    # Sort by start_date
    mayor_data.sort(key=lambda x: x['start_date'])
    return mayor_data

def match_mayor_perks(timestamp, mayor_data):
    if not mayor_data:
        return [0] * 40
        
    if isinstance(timestamp, str):
        try:
            timestamp = datetime.fromisoformat(timestamp.replace("Z", "+00:00"))
        except:
            return [0] * 40

    for i, mayor in enumerate(mayor_data):
        next_start = mayor_data[i + 1]['start_date'] if i + 1 < len(mayor_data) else None
        if next_start:
            if mayor['start_date'] <= timestamp < next_start:
                return mayor['perks']
        else:
            if mayor['start_date'] <= timestamp:
                return mayor['perks']

    return [0] * 40

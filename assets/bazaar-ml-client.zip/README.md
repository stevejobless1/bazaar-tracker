---
title: Bazaar Prediction Engine
emoji: 🧠
colorFrom: blue
colorTo: cyan
sdk: docker
pinned: false
app_port: 7860
---

# Bazaar Price Prediction Engine
ML microservice for Skyblock Bazaar trend analysis.

## Setup
This space runs a Flask API on port 7860 that provides LightGBM-based price predictions.

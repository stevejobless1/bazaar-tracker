import os
import sys
import optuna
import json
import numpy as np
import pandas as pd
import joblib
import lightgbm as lgb
import requests
import warnings
from datetime import datetime, timedelta, timezone
from sklearn.preprocessing import StandardScaler
from sklearn.metrics import r2_score

# Add current dir to path for local imports
script_dir = os.path.dirname(os.path.abspath(__file__))
if script_dir not in sys.path:
    sys.path.insert(0, script_dir)

from Utils.event_utils import add_skyblock_time_features
from Utils.data_utils import load_or_fetch_item_data, parse_timestamp
from Utils.mayor_utils import get_mayor_perks, match_mayor_perks

warnings.filterwarnings("ignore")

def clean_dump(obj, path):
    tmp = path + ".tmp"
    joblib.dump(obj, tmp)
    try:
        with open(tmp, "r+b") as f:
            f.flush()
            os.fsync(f.fileno())
    except (OSError, IOError):
        pass
    if os.path.exists(path):
        os.remove(path)
    os.rename(tmp, path)

def clean_infinite_values(X):
    X = np.asarray(X, dtype=np.float64)
    X = np.nan_to_num(X, nan=0.0, posinf=1e8, neginf=-1e8)
    return np.clip(X, -1e8, 1e8)

def clip_extreme_outliers(y, threshold=0.25):
    y = np.asarray(y)
    return np.clip(y, -threshold, threshold)

def remove_extremes(X, y, cutoff=0.5):
    mask = np.abs(y) <= cutoff
    return X[mask], y[mask]

def add_time_features(df, ts_col='timestamp'):
    dt = pd.to_datetime(df[ts_col])
    df['hour'] = dt.dt.hour
    df['minute'] = dt.dt.minute
    df['dayofweek'] = dt.dt.dayofweek
    df['hour_sin'] = np.sin(2*np.pi*df['hour']/24)
    df['hour_cos'] = np.cos(2*np.pi*df['hour']/24)
    df['dow_sin'] = np.sin(2*np.pi*df['dayofweek']/7)
    df['dow_cos'] = np.cos(2*np.pi*df['dayofweek']/7)
    df['delta_minutes'] = df['timestamp'].diff().dt.total_seconds().fillna(0) / 60
    return df

def build_lagged_features(df, price_col='buy_price', vol_col='buy_volume', lags=(1, 2, 3, 6, 12), prefix=''):
    ret = df[price_col].pct_change()
    df[f'{prefix}ret'] = ret
    for lag in lags:
        df[f'{prefix}ret_lag_{lag}'] = ret.shift(lag)
        df[f'{prefix}price_lag_{lag}'] = df[price_col].shift(lag)
        df[f'{prefix}vol_lag_{lag}'] = df[vol_col].shift(lag)
    df[f'{prefix}roll_mean_6'] = ret.rolling(6).mean()
    df[f'{prefix}roll_std_6'] = ret.rolling(6).std()
    df[f'{prefix}mom_6'] = ret.rolling(6).sum()
    return df

def prepare_dataframe_from_raw(data, mayor_data=None):
    rows = []
    for entry in data:
        try:
            ts = parse_timestamp(entry['timestamp'])
        except:
            continue
        def f(k):
            try: return float(entry.get(k, 0))
            except: return 0.0
        row = {
            'timestamp': ts,
            'buy_price': f('buy'),
            'sell_price': f('sell'),
            'buy_volume': f('buyVolume'),
            'sell_volume': f('sellVolume'),
            'max_buy': f('maxBuy'),
            'min_buy': f('minBuy'),
        }
        if mayor_data is not None:
            perks = match_mayor_perks(ts, mayor_data)
            for i, v in enumerate(perks):
                row[f'mayor_{i}'] = v
        rows.append(row)
    df = pd.DataFrame(rows)
    if df.empty: return df
    df = df.sort_values('timestamp').reset_index(drop=True)
    df = add_time_features(df)
    df = build_lagged_features(df, price_col='buy_price', vol_col='buy_volume', prefix='buy_')
    df = add_skyblock_time_features(df, ts_col='timestamp')
    return df

def build_entry_targets(df, horizon_minutes=180, tax=0.0125):
    df = df.copy().sort_values('timestamp').reset_index(drop=True)
    ts = pd.to_datetime(df['timestamp']).astype('int64') // 10**9
    ts = ts.values
    horizon_sec = horizon_minutes * 60
    buy_prices = df['buy_price'].values
    sell_prices = df['sell_price'].values
    n = len(df)
    expected_return = np.zeros(n)
    profit_prob = np.zeros(n)
    # Simplified target construction for speed and stability
    initial_gaps = buy_prices * (1 - tax) - sell_prices
    j = 0
    for i in range(n):
        entry_price = sell_prices[i]
        initial_gap = initial_gaps[i]
        while j < n and ts[j] - ts[i] <= horizon_sec:
            j += 1
        if j <= i: continue
        returns_full = (buy_prices[i:j] * (1 - tax) - entry_price) - initial_gap
        returns_full = returns_full / (entry_price + 1e-9)
        time_deltas = ts[i:j] - ts[i]
        min_delay = 10 * 60
        mask = time_deltas > min_delay
        if np.any(mask):
            returns_horizon = returns_full[mask]
            expected_return[i] = np.median(returns_horizon)
            profit_prob[i] = np.mean(returns_horizon > 0)
    df['entry_label'] = expected_return
    df['profit_prob'] = profit_prob
    return df

def entry_objective(trial, X, y):
    split_idx = int(len(X) * 0.8)
    X_train, X_val = X[:split_idx], X[split_idx:]
    y_train, y_val = y[:split_idx], y[split_idx:]
    clip_thr = trial.suggest_float("label_clip", 0.01, 0.5, log=True)
    y_train = np.clip(y_train, -clip_thr, clip_thr)
    y_val = np.clip(y_val, -clip_thr, clip_thr)
    sign_penalty = trial.suggest_float("sign_penalty", 1.0, 5.0)
    params = {
        "objective": "regression",
        "learning_rate": trial.suggest_float("lr", 0.01, 0.15, log=True),
        "num_leaves": trial.suggest_int("num_leaves", 16, 64),
        "feature_fraction": 0.8,
        "bagging_fraction": 0.8,
        "bagging_freq": 3,
        "verbosity": -1
    }
    dtrain = lgb.Dataset(X_train, label=y_train)
    model = lgb.train(params, dtrain, num_boost_round=200)
    preds = model.predict(X_val)
    sq_errors = (preds - y_val) ** 2
    wrong_sign = np.sign(preds) != np.sign(y_val)
    weights = np.ones_like(sq_errors)
    weights[wrong_sign] = sign_penalty
    return np.sqrt(np.mean(weights * sq_errors))

def train_model_system(item_id):
    mayor_data = get_mayor_perks()
    data = load_or_fetch_item_data(item_id)
    df = prepare_dataframe_from_raw(data, mayor_data)
    if df.empty: return
    df = build_entry_targets(df)
    exclude = {'timestamp', 'entry_label', 'profit_prob'}
    feature_cols = [c for c in df.columns if c not in exclude]
    X = clean_infinite_values(df[feature_cols].values)
    y = df['entry_label'].values
    scaler = StandardScaler()
    X_scaled = scaler.fit_transform(X)
    X_scaled, y = remove_extremes(X_scaled, y, cutoff=0.5)
    study = optuna.create_study(direction="minimize")
    study.optimize(lambda t: entry_objective(t, X_scaled, y), n_trials=10) # Reduced for testing
    params = study.best_params
    best_clip = params.pop("label_clip")
    params.update({"objective": "regression", "metric": "rmse", "verbosity": -1})
    y = clip_extreme_outliers(y, threshold=best_clip)
    model = lgb.train(params, lgb.Dataset(X_scaled, label=y), num_boost_round=300)
    model_dir = os.path.join(script_dir, "Model_Files")
    os.makedirs(model_dir, exist_ok=True)
    base = os.path.join(model_dir, str(item_id))
    clean_dump(model, base + "_entry_model.pkl")
    clean_dump(scaler, base + "_entry_scaler.pkl")
    clean_dump(feature_cols, base + "_entry_features.pkl")
    print(f"✅ Saved models for {item_id}")

def predict_entries(model, scaler, feature_cols, item_id, mayor_data=None, horizon_hours=3, step_minutes=5):
    now = datetime.now(timezone.utc)
    start = now - timedelta(hours=horizon_hours)
    start_str = start.strftime("%Y-%m-%dT%H:%M:%S.000")
    end_str = now.strftime("%Y-%m-%dT%H:%M:%S.000")
    # This will fetch live data from Coflnet
    data = load_or_fetch_item_data(item_id, start_str, end_str)
    df = prepare_dataframe_from_raw(data, mayor_data)
    if df.empty: return []
    last_row = df.iloc[-1:].copy()
    future_times = pd.date_range(start=now, periods=int(horizon_hours*60/step_minutes), freq=f"{step_minutes}min")
    preds = []
    for ts in future_times:
        row = last_row.copy()
        row['timestamp'] = ts
        if mayor_data is not None:
            perks = match_mayor_perks(ts, mayor_data)
            for i, v in enumerate(perks): row[f'mayor_{i}'] = v
        for c in feature_cols:
            if c not in row.columns: row[c] = 0.0
        X = clean_infinite_values(row[feature_cols].values)
        X_scaled = scaler.transform(X)
        y_pred = model.predict(X_scaled)[0]
        preds.append({
            'timestamp': ts.isoformat(),
            'buy_price': float(row['buy_price'].iloc[0]),
            'sell_price': float(row['sell_price'].iloc[0]),
            'entry_score': float(y_pred)
        })
    return preds

def analyze_entries(pred_list):
    if not pred_list: return []
    now = datetime.now(timezone.utc)
    enriched = []
    for e in pred_list:
        score = float(e.get('entry_score', 0.0))
        if score <= 0: continue
        ts = datetime.fromisoformat(e.get('timestamp'))
        delta = (ts - now).total_seconds() / 60.0
        if delta < 0: continue
        entry = dict(e)
        entry['delta_minutes'] = float(delta)
        enriched.append(entry)
    enriched.sort(key=lambda x: (x['delta_minutes'], -x['entry_score']))
    return enriched
